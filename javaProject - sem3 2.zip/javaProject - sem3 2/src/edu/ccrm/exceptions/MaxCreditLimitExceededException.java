
package edu.ccrm.exceptions;

public class MaxCreditLimitExceededException extends Exception {
    public MaxCreditLimitExceededException(String msg){ super(msg); }
}
